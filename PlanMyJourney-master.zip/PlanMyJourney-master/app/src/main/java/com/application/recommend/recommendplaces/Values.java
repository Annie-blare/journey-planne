package com.application.recommend.recommendplaces;

/**
 * Created by Akarsh on 28-01-2018.
 */

public class Values {

    String CLIENT_ID = "0Y13VO4S0HUYMZKGFNB2AHEYEFLL31VZXGJ2UX02G31WZIKN";
    String CLIENT_SECRET = "CDI1NS2CWHLUCDYBMVIDT51QEUNGSZRJ3QPLTMLLALJXJQF2";

    public String getCLIENT_ID() {
        return CLIENT_ID;
    }

    public String getCLIENT_SECRET() {
        return CLIENT_SECRET;
    }
}
