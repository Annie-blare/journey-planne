package com.application.recommend.recommendplaces;

/**
 * Created by lenovo on 1/17/2018.
 */

public class MyInfo {
    public String name,email,dob,pass,phone,otp;
    MyInfo(){

    }
    MyInfo(String name,String email,String dob,String pass,String phone,String otp)
    {
        //this.key=key;
        this.name=name;
        this.email=email;
        this.dob=dob;
        this.pass=pass;
        this.phone=phone;
        this.otp=otp;
    }
}
