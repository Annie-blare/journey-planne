# Plan My Journey

An android application that will suggest places to visit (like cafe, food courts, cinema etc.) between the source and the destination. The application will also display a map pin-pointing the places along with the order in which they can be optimally visited (starting from the source, visiting all the places and reaching the destination) along with the distance.

This application provides all the details of the places mentioned including the opening/closing times, rating, user reviews, location on map (with the facility of navigation to the place from another/current loaction), contact number, photos etc.

This application also filters the results based on the current status of the place (i.e. opened or closed).
